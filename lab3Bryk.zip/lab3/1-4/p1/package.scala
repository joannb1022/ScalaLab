package object p1 {
  def m1(i: Int) = 2 * i
  def m2(d: Double) = 1.5 * d
}
